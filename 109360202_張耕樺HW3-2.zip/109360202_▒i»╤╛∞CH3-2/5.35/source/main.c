#include<stdio.h>
#include<stdlib.h>

unsigned long long int fibonacci(int a);

int main(void)
{ 
	unsigned int a;
	printf("�п�J��X�O���ƦC�ĴX�Ӽƭ�:");
	scanf_s("%d", &a);
	printf("���ƦC���̤j�Ƭ�:%d\n", fibonacci(a));
	system("pause");
	return 0;
}

unsigned long long int fibonacci(int a)
{
	long long  i[100];
	int fib;
	i[0] = 0;
	i[1] = 1;

	for (fib = 2; fib < a; fib++)
	{
		i[fib] = i[fib-1] + i[fib-2];
	}
	
	for (fib = 2; fib < a; fib++)
	{
		printf("%d ", i[fib]);
	}
	return i[fib - 1];//fib����J��
}