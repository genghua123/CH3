#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main(void)
{
	char a,c;
	printf("�п�J�@�Ӧr��:");
	scanf_s("%c", &a);

	if ((a >= 65) && (a <= 90))
	{
		c = a + 32;
		printf("%c\n", c);
	}
	else if ((a >= 97) && (a <= 122))
	{
		c = (a - 32);
		printf("%c\n", c);
	}
	system("pause");
	return 0;
}