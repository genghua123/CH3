#include<stdio.h>
#include<stdlib.h>

int function (int b, int e);

int main(void)
{
	int b, e;
	printf("��J��ƩM����:");
	scanf_s("%d %d", &b, &e);

	printf("%d �� %d ����=%d\n", b, e, function(b, e));
	system("pause");
	return 0;
}

int function(int b, int e)
{
	if (e == 1)
	{
		return b;
	}
	else if (e==0)
	{
		return 1;
	}
	else
	{
		return ( b * function(b,e-1));
	}
}