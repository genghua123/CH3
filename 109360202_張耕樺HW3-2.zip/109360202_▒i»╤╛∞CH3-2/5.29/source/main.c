#include<stdio.h>
#include<stdlib.h>

int GCD(int a, int b);
int LCM(int a, int b);

int main(void)
{
	int a, b;
	printf("�п�J���:");
	scanf_s("%d %d", &a, &b);
	printf("�̤p�����Ƭ�:%d\n",LCM(a, b));

	system("pause");
	return 0;
}

int GCD(int a, int b)
{
	while (b != 0) 
	{
		int r;
		r= a % b;
		a = b;
		b = r;
	}
	return a;
}

int LCM(int a, int b)
{
	return a * b / GCD(a, b);
}